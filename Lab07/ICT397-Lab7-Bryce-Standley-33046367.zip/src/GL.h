#if __APPLE__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#endif

#include <glad/glad.h>
#include <GLFW/glfw3.h>


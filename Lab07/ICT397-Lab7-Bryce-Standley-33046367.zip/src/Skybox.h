#pragma once
#ifndef SKYBOX_H
#define SKYBOX_H
#include "Texture.h"
#include <iostream>
#include "Shader.h"
#include <vector>
#include <memory>
#include <string>

class Skybox
{
public:
    Skybox() = default;
    ~Skybox();
    void Init();
    void Draw(const glm::mat4& view, const glm::mat4& projection) const;
    unsigned int loadCubemap(std::vector<std::string> faces);
    std::unique_ptr<Shader> skyShader = nullptr;

private:
    unsigned int skyboxVAO = 0, skyboxVBO = 0;
    unsigned int cubeTexture = 0;
    std::vector<std::string> cubeFaces = {};

    float skyBoxVertices[108] =  {
            // positions
            -1.0f, 1.0f,  -1.0f, -1.0f, -1.0f, -1.0f, 1.0f,  -1.0f, -1.0f,
            1.0f,  -1.0f, -1.0f, 1.0f,  1.0f,  -1.0f, -1.0f, 1.0f,  -1.0f,

            -1.0f, -1.0f, 1.0f,  -1.0f, -1.0f, -1.0f, -1.0f, 1.0f,  -1.0f,
            -1.0f, 1.0f,  -1.0f, -1.0f, 1.0f,  1.0f,  -1.0f, -1.0f, 1.0f,

            1.0f,  -1.0f, -1.0f, 1.0f,  -1.0f, 1.0f,  1.0f,  1.0f,  1.0f,
            1.0f,  1.0f,  1.0f,  1.0f,  1.0f,  -1.0f, 1.0f,  -1.0f, -1.0f,

            -1.0f, -1.0f, 1.0f,  -1.0f, 1.0f,  1.0f,  1.0f,  1.0f,  1.0f,
            1.0f,  1.0f,  1.0f,  1.0f,  -1.0f, 1.0f,  -1.0f, -1.0f, 1.0f,

            -1.0f, 1.0f,  -1.0f, 1.0f,  1.0f,  -1.0f, 1.0f,  1.0f,  1.0f,
            1.0f,  1.0f,  1.0f,  -1.0f, 1.0f,  1.0f,  -1.0f, 1.0f,  -1.0f,

            -1.0f, -1.0f, -1.0f, -1.0f, -1.0f, 1.0f,  1.0f,  -1.0f, -1.0f,
            1.0f,  -1.0f, -1.0f, -1.0f, -1.0f, 1.0f,  1.0f,  -1.0f, 1.0f};


};

#endif //LAB07_SKYBOX_H
